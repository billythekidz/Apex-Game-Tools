﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using System;
    using Apex.AI;
    using Apex.AI.Components;
    using UnityEngine;

    public sealed class ApexPathContextProvider : MonoBehaviour, IContextProvider
    {
        private ApexPathContext _context;

        public void OnEnable()
        {
            _context = new ApexPathContext(this.GetUnitFacade());
        }

        public IAIContext GetContext(Guid aiId)
        {
            return _context;
        }
    }
}