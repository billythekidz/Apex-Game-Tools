﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using Apex.AI;

    public sealed class ApexPathIsNotMoving : ContextualScorerBase<ApexPathContext>
    {
        public override float Score(ApexPathContext context)
        {
            // If we are moving, we return 0
            if (context.unitFacade.velocity.sqrMagnitude > 0f)
            {
                return 0f;
            }

            return this.score;
        }
    }
}