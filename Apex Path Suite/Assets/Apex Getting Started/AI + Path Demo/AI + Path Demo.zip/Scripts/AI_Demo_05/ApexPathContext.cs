﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using Apex.AI;
    using Units;

    public sealed class ApexPathContext : IAIContext
    {
        public ApexPathContext(IUnitFacade unitFacade)
        {
            this.unitFacade = unitFacade;
        }

        // The UnitFacade will act like the NavMeshAgent did in AI Demo 1
        public IUnitFacade unitFacade
        {
            get;
            private set;
        }
    }
}