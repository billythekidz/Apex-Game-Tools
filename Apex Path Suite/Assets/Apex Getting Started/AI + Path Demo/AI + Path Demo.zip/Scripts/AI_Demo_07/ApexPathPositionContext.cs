﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using System.Collections.Generic;
    using Apex.AI;
    using Units;
    using UnityEngine;

    public sealed class ApexPathPositionContext : IAIContext
    {
        public ApexPathPositionContext(IUnitFacade unitFacade)
        {
            this.unitFacade = unitFacade;
            this.positions = new List<Vector3>();
        }

        public IUnitFacade unitFacade
        {
            get;
            private set;
        }

        public IList<Vector3> positions
        {
            get;
            private set;
        }
    }
}