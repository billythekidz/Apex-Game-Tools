﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using Apex.AI;
    using Serialization;
    using UnityEngine;
    using WorldGeometry;

    public sealed class ApexPathPositionScanner : ActionBase<ApexPathPositionContext>
    {
        [ApexSerialization(defaultValue = 12f), FriendlyName("Sampling Range", "The range in which the Scanner will sample positions")]
        public float samplingRange = 12f;

        [ApexSerialization(defaultValue = 1.5f), FriendlyName("Sampling Density", "The density in which the Scanner will sample positions")]
        public float samplingDensity = 1.5f;

        // This will loop through all possible positions within the samplingRange and with a density equal to the samplingDensity
        // Then check if that position is walkable or not, if it is we add it to the list of positions
        public override void Execute(ApexPathPositionContext context)
        {
            context.positions.Clear();

            var unitFacade = context.unitFacade;
            var gridManager = GridManager.instance;
            var position = context.unitFacade.position;
            var halfSamplingRange = this.samplingRange * 0.5f;
            for (float x = -halfSamplingRange; x <= halfSamplingRange; x += this.samplingDensity)
            {
                for (float z = -halfSamplingRange; z <= halfSamplingRange; z += this.samplingDensity)
                {
                    var point = new Vector3(position.x + x, 0f, position.z + z);

                    var grid = gridManager.GetGrid(point);
                    if (grid == null)
                    {
                        continue;
                    }

                    var cell = grid.GetCell(point, false);
                    if (cell.isPermanentlyBlocked || !cell.IsWalkable(unitFacade.attributes))
                    {
                        continue;
                    }

                    context.positions.Add(point);
                }
            }
        }
    }
}