﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using System;
    using Apex.AI;
    using Apex.AI.Components;
    using UnityEngine;

    public sealed class ApexPathPositionContextProvider : MonoBehaviour, IContextProvider
    {
        private ApexPathPositionContext _context;

        public void OnEnable()
        {
            _context = new ApexPathPositionContext(this.GetUnitFacade());
        }

        public IAIContext GetContext(Guid aiId)
        {
            return _context;
        }
    }
}