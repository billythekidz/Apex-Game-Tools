﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using Apex.AI;
    using Units;
    using UnityEngine;

    public sealed class ApexPathTargetContext : IAIContext
    {
        public ApexPathTargetContext(IUnitFacade facade, GameObject[] targets)
        {
            this.unitFacade = facade;
            this.targets = targets;
        }

        public IUnitFacade unitFacade
        {
            get;
            private set;
        }

        public GameObject[] targets
        {
            get;
            private set;
        }
    }
}