﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using Apex.AI;
    using UnityEngine;

    public sealed class ApexPathRotateToTarget : ActionWithOptions<GameObject>
    {
        public override void Execute(IAIContext c)
        {
            var context = (ApexPathTargetContext)c;

            var best = this.GetBest(context, context.targets);
            if (best == null)
            {
                return;
            }

            // We set this field to be equal to the position we want to rotate towards
            context.unitFacade.lookAt = best.transform.position;
        }
    }
}