﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using Apex.AI;
    using Units;
    using UnityEngine;

    public sealed class WanderContext : IAIContext
    {
        public WanderContext(IUnitFacade unitFacade)
        {
            this.unitFacade = unitFacade;
            this.renderer = unitFacade.gameObject.GetComponent<Renderer>();
        }

        // This bool is for keeping track of whether we are wandering or not, so we can use it for our Scorer
        public bool isWandering
        {
            get;
            set;
        }

        public IUnitFacade unitFacade
        {
            get;
            private set;
        }

        // We store the Renderer in the context so we only have to call GetComponent() once
        public Renderer renderer
        {
            get;
            private set;
        }
    }
}