﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using Apex.AI;
    using Serialization;
    using Steering.Behaviours;
    using UnityEngine;

    public sealed class Wander : ActionBase<WanderContext>, IRequireTermination
    {
        [ApexSerialization(defaultValue = 5f), FriendlyName("Radius", "The radius in which the AI will wander")]
        public float radius = 5f;

        [ApexSerialization(defaultValue = 2.5f), FriendlyName("Minimum Distance", "The minimum distance the AI will wander")]
        public float minimumDistance = 2.5f;

        [ApexSerialization(defaultValue = 1f), FriendlyName("Seconds to Linger", "How many seconds to linger at each destination before moving on")]
        public float lingerForSeconds = 1f;

        public override void Execute(WanderContext context)
        {
            // Tell the Unit to start wandering
            WanderMaster.Wander(context.unitFacade, radius, minimumDistance, lingerForSeconds);
            context.isWandering = true;

            // Set the color of the Unit to green
            context.renderer.material.color = Color.green;
        }

        // This method will be called once the AI changes action
        public void Terminate(IAIContext c)
        {
            var context = (WanderContext)c;

            // Tell the Unit to stop wandering
            WanderMaster.StopWander(context.unitFacade);
            context.isWandering = false;

            // Set the color of the Unit to red
            context.renderer.material.color = Color.red;
        }
    }
}