﻿namespace Apex.GettingStarted.AI.ApexPath
{
    using Apex.AI;

    public sealed class ShouldWander : ContextualScorerBase<WanderContext>
    {
        public override float Score(WanderContext context)
        {
            return context.isWandering ? 0f : this.score;
        }
    }
}