﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;
    using Units;
    using UnityEngine;

    public sealed class MakeGroupContext : IAIContext
    {
        public MakeGroupContext(GameObject[] potentialMembers)
        {
            this.potentialMembers = potentialMembers;
        }

        public GameObject[] potentialMembers
        {
            get;
            private set;
        }

        // This is where the group is stored, once created
        public TransientGroup<IUnitFacade> group
        {
            get;
            set;
        }
    }
}