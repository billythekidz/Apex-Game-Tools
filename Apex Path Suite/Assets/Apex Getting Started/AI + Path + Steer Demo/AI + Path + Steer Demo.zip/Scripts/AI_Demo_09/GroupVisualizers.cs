﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using System;
    using Apex.AI;
    using Apex.AI.Visualization;
    using Units;
    using UnityEngine;

    public sealed class GroupVisualizers : CustomGizmoVisualizerComponent<MakeGroup, TransientGroup<IUnitFacade>>
    {
        protected override void DrawGizmos(TransientGroup<IUnitFacade> group)
        {
            Gizmos.color = Color.cyan;
            for (int i = 0; i < group.count; i++)
            {
                var transform = group[i].transform;
                Gizmos.DrawCube(transform.position, transform.localScale);
            }
        }

        protected override TransientGroup<IUnitFacade> GetDataForVisualization(MakeGroup aiEntity, IAIContext context, Guid aiId)
        {
            return ((MakeGroupContext)context).group;
        }
    }
}