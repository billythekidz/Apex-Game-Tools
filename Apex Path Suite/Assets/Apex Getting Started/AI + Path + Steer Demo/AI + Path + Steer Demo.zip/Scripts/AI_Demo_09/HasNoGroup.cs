﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;

    public sealed class HasNoGroup : ContextualScorerBase<MakeGroupContext>
    {
        public override float Score(MakeGroupContext context)
        {
            return context.group == null ? this.score : 0f;
        }
    }
}