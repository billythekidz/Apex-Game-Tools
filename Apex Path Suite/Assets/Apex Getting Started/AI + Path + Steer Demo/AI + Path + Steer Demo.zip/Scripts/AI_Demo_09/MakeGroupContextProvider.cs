﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using System;
    using Apex.AI;
    using Apex.AI.Components;
    using UnityEngine;

    public sealed class MakeGroupContextProvider : MonoBehaviour, IContextProvider
    {
        [SerializeField]
        private GameObject[] potentialMembers = new GameObject[0];

        private MakeGroupContext _context;

        public void OnEnable()
        {
            _context = new MakeGroupContext(potentialMembers);
        }

        public IAIContext GetContext(Guid aiId)
        {
            return _context;
        }
    }
}