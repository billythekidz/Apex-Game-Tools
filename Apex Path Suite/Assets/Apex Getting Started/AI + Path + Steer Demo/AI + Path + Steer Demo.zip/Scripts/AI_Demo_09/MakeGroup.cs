﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;
    using Units;

    public sealed class MakeGroup : ActionBase<MakeGroupContext>
    {
        public override void Execute(MakeGroupContext context)
        {
            context.group = GroupingManager.CreateGroup(context.potentialMembers.ToUnitFacades());
        }
    }
}