﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;
    using Steering;
    using UnityEngine;

    public sealed class UpdateFormation : ActionBase<FormationContext>
    {
        // Sets a random formation on the group
        public override void Execute(FormationContext context)
        {
            var group = context.group;
            IFormation formation = null;
            do
            {
                var rand = Random.Range(0, context.formations.Length);
                formation = context.formations[rand];
            }
            while (ReferenceEquals(context.lastFormation, formation)); // We compare the random formation to the last formation used, so we don't set the same formation that we already have

            group.SetFormation(formation);
            context.lastFormation = formation;
        }
    }
}