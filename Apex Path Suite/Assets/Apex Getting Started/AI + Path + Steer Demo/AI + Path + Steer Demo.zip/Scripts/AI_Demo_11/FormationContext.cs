﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;
    using Steering;
    using Units;

    public sealed class FormationContext : IAIContext
    {
        // Here we store the different Formations we want the group to select from
        public readonly IFormation[] formations = { new FormationWing(2f), new FormationSpiral(2f), new FormationEllipsoid(2f), new FormationRow(2f), new FormationGrid(2f), new FormationLine(2f) };

        public FormationContext(TransientGroup<IUnitFacade> group)
        {
            this.group = group;
        }

        public IFormation lastFormation
        {
            get;
            set;
        }

        public TransientGroup<IUnitFacade> group
        {
            get;
            private set;
        }
    }
}