﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using System;
    using Apex.AI;
    using Apex.AI.Components;
    using Units;
    using UnityEngine;

    public sealed class FormationContextProvider : MonoBehaviour, IContextProvider
    {
        [SerializeField]
        private GameObject[] members = new GameObject[0];

        private FormationContext _context;

        public void OnEnable()
        {
            var newGroup = GroupingManager.CreateGroup(members.ToUnitFacades());
            _context = new FormationContext(newGroup);
        }

        public IAIContext GetContext(Guid aiId)
        {
            return _context;
        }
    }
}