﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;

    public sealed class HasFormation : ContextualScorerBase<FormationContext>
    {
        public override float Score(FormationContext context)
        {
            return context.group.currentFormation == null ? 0f : this.score;
        }
    }
}