﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;

    public sealed class ClearFormation : ActionBase<FormationContext>
    {
        public override void Execute(FormationContext context)
        {
            context.group.ClearFormation();
        }
    }
}