﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;
    using Units;

    public sealed class GroupContext : IAIContext
    {
        public GroupContext(TransientGroup<IUnitFacade> group)
        {
            this.group = group;
        }

        public TransientGroup<IUnitFacade> group
        {
            get;
            private set;
        }
    }
}