﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;

    public sealed class GroupIsNotMoving : ContextualScorerBase<GroupContext>
    {
        public override float Score(GroupContext context)
        {
            if (context.group.velocity.sqrMagnitude > 0f)
            {
                return 0f;
            }

            return this.score;
        }
    }
}