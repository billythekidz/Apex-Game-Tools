﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using Apex.AI;
    using Serialization;
    using UnityEngine;
    using WorldGeometry;

    public sealed class GroupRandomMove : ActionBase<GroupContext>
    {
        [ApexSerialization(defaultValue = 5f), FriendlyName("Move Radius", "The radius in which the Units will randomly move")]
        public float moveRadius = 5f;

        public override void Execute(GroupContext context)
        {
            var randomPosition = Random.onUnitSphere * this.moveRadius;
            randomPosition.y = 0f;

            // We need to get the grid the positions is on
            var grid = GridManager.instance.GetGrid(randomPosition);
            if (grid == null)
            {
                return;
            }

            // And we get the cell on the grid and check if it's walkable or not
            var cell = grid.GetCell(randomPosition, false);
            if (cell.isPermanentlyBlocked || !cell.IsWalkable(context.group.modelUnit.attributes))
            {
                return;
            }

            // Then we move towards that position
            context.group.MoveTo(randomPosition, false);
        }
    }
}