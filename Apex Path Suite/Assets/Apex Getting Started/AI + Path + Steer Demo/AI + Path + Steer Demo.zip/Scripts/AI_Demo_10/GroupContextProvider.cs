﻿namespace Apex.GettingStarted.AI.ApexSteer
{
    using System;
    using Apex.AI;
    using Apex.AI.Components;
    using Units;
    using UnityEngine;

    public sealed class GroupContextProvider : MonoBehaviour, IContextProvider
    {
        [SerializeField]
        private GameObject[] groupMembers = new GameObject[0];

        private GroupContext _context;

        public void OnEnable()
        {
            _context = new GroupContext(GroupingManager.CreateGroup(groupMembers.ToUnitFacades()));
        }

        public IAIContext GetContext(Guid aiId)
        {
            return _context;
        }
    }
}